﻿namespace Kelompok_1__Program_Linear_
{
    partial class form_main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.datagrid_userinput = new System.Windows.Forms.DataGridView();
            this.datagrid_useroutput = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.artanPanel1 = new Kelompok_1__Program_Linear_.ArtanPanel();
            this.label4 = new System.Windows.Forms.Label();
            this.artanPanel4 = new Kelompok_1__Program_Linear_.ArtanPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.combobox_tabeliterasi = new System.Windows.Forms.ComboBox();
            this.btn_tampilkantabel = new System.Windows.Forms.Button();
            this.artanPanel3 = new Kelompok_1__Program_Linear_.ArtanPanel();
            this.btn_generatetable = new System.Windows.Forms.Button();
            this.btn_calculate = new System.Windows.Forms.Button();
            this.artanPanel2 = new Kelompok_1__Program_Linear_.ArtanPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtbox_jumlahconstraint = new System.Windows.Forms.TextBox();
            this.txtbox_jumlahvariabel = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid_userinput)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid_useroutput)).BeginInit();
            this.artanPanel1.SuspendLayout();
            this.artanPanel4.SuspendLayout();
            this.artanPanel3.SuspendLayout();
            this.artanPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // datagrid_userinput
            // 
            this.datagrid_userinput.AllowUserToAddRows = false;
            this.datagrid_userinput.AllowUserToDeleteRows = false;
            this.datagrid_userinput.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagrid_userinput.Location = new System.Drawing.Point(351, 71);
            this.datagrid_userinput.Margin = new System.Windows.Forms.Padding(4);
            this.datagrid_userinput.Name = "datagrid_userinput";
            this.datagrid_userinput.RowHeadersWidth = 51;
            this.datagrid_userinput.Size = new System.Drawing.Size(1145, 309);
            this.datagrid_userinput.TabIndex = 3;
            // 
            // datagrid_useroutput
            // 
            this.datagrid_useroutput.AllowUserToAddRows = false;
            this.datagrid_useroutput.AllowUserToDeleteRows = false;
            this.datagrid_useroutput.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagrid_useroutput.Location = new System.Drawing.Point(351, 429);
            this.datagrid_useroutput.Margin = new System.Windows.Forms.Padding(4);
            this.datagrid_useroutput.Name = "datagrid_useroutput";
            this.datagrid_useroutput.RowHeadersWidth = 51;
            this.datagrid_useroutput.Size = new System.Drawing.Size(1145, 296);
            this.datagrid_useroutput.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Montserrat", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(344, 384);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(210, 41);
            this.label5.TabIndex = 15;
            this.label5.Text = "Tabel Iterasi";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Montserrat", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(344, 28);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(282, 41);
            this.label6.TabIndex = 16;
            this.label6.Text = "Tabel Input Data";
            // 
            // artanPanel1
            // 
            this.artanPanel1.BackColor = System.Drawing.Color.White;
            this.artanPanel1.BorderRadius = 90;
            this.artanPanel1.Controls.Add(this.label4);
            this.artanPanel1.Controls.Add(this.artanPanel4);
            this.artanPanel1.Controls.Add(this.artanPanel3);
            this.artanPanel1.Controls.Add(this.artanPanel2);
            this.artanPanel1.ForeColor = System.Drawing.Color.Transparent;
            this.artanPanel1.GradientAngle = 90F;
            this.artanPanel1.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(94)))), ((int)(((byte)(62)))));
            this.artanPanel1.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(155)))), ((int)(((byte)(80)))));
            this.artanPanel1.Location = new System.Drawing.Point(-43, 0);
            this.artanPanel1.Name = "artanPanel1";
            this.artanPanel1.Size = new System.Drawing.Size(356, 759);
            this.artanPanel1.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Montserrat", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(99, 41);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(199, 41);
            this.label4.TabIndex = 7;
            this.label4.Text = "Kelompok 1";
            // 
            // artanPanel4
            // 
            this.artanPanel4.BackColor = System.Drawing.Color.White;
            this.artanPanel4.BorderRadius = 50;
            this.artanPanel4.Controls.Add(this.label1);
            this.artanPanel4.Controls.Add(this.combobox_tabeliterasi);
            this.artanPanel4.Controls.Add(this.btn_tampilkantabel);
            this.artanPanel4.ForeColor = System.Drawing.Color.Transparent;
            this.artanPanel4.GradientAngle = 90F;
            this.artanPanel4.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(61)))), ((int)(((byte)(47)))));
            this.artanPanel4.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(61)))), ((int)(((byte)(47)))));
            this.artanPanel4.Location = new System.Drawing.Point(55, 503);
            this.artanPanel4.Name = "artanPanel4";
            this.artanPanel4.Size = new System.Drawing.Size(276, 167);
            this.artanPanel4.TabIndex = 14;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Montserrat", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(31, 23);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 24);
            this.label1.TabIndex = 7;
            this.label1.Text = "Tabel Iteasi";
            // 
            // combobox_tabeliterasi
            // 
            this.combobox_tabeliterasi.FormattingEnabled = true;
            this.combobox_tabeliterasi.Location = new System.Drawing.Point(35, 51);
            this.combobox_tabeliterasi.Margin = new System.Windows.Forms.Padding(4);
            this.combobox_tabeliterasi.Name = "combobox_tabeliterasi";
            this.combobox_tabeliterasi.Size = new System.Drawing.Size(211, 24);
            this.combobox_tabeliterasi.TabIndex = 9;
            // 
            // btn_tampilkantabel
            // 
            this.btn_tampilkantabel.BackColor = System.Drawing.Color.White;
            this.btn_tampilkantabel.Font = new System.Drawing.Font("Montserrat", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_tampilkantabel.ForeColor = System.Drawing.Color.Black;
            this.btn_tampilkantabel.Location = new System.Drawing.Point(35, 97);
            this.btn_tampilkantabel.Margin = new System.Windows.Forms.Padding(4);
            this.btn_tampilkantabel.Name = "btn_tampilkantabel";
            this.btn_tampilkantabel.Size = new System.Drawing.Size(211, 53);
            this.btn_tampilkantabel.TabIndex = 10;
            this.btn_tampilkantabel.Text = "Tampilkan";
            this.btn_tampilkantabel.UseVisualStyleBackColor = false;
            this.btn_tampilkantabel.Click += new System.EventHandler(this.btn_tampilkantabel_Click);
            // 
            // artanPanel3
            // 
            this.artanPanel3.BackColor = System.Drawing.Color.White;
            this.artanPanel3.BorderRadius = 50;
            this.artanPanel3.Controls.Add(this.btn_generatetable);
            this.artanPanel3.Controls.Add(this.btn_calculate);
            this.artanPanel3.ForeColor = System.Drawing.Color.Transparent;
            this.artanPanel3.GradientAngle = 90F;
            this.artanPanel3.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(61)))), ((int)(((byte)(47)))));
            this.artanPanel3.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(61)))), ((int)(((byte)(47)))));
            this.artanPanel3.Location = new System.Drawing.Point(55, 300);
            this.artanPanel3.Name = "artanPanel3";
            this.artanPanel3.Size = new System.Drawing.Size(276, 177);
            this.artanPanel3.TabIndex = 13;
            // 
            // btn_generatetable
            // 
            this.btn_generatetable.BackColor = System.Drawing.Color.Transparent;
            this.btn_generatetable.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_generatetable.ForeColor = System.Drawing.Color.Black;
            this.btn_generatetable.Location = new System.Drawing.Point(35, 27);
            this.btn_generatetable.Margin = new System.Windows.Forms.Padding(4);
            this.btn_generatetable.Name = "btn_generatetable";
            this.btn_generatetable.Size = new System.Drawing.Size(211, 53);
            this.btn_generatetable.TabIndex = 2;
            this.btn_generatetable.Text = "Generate Table";
            this.btn_generatetable.UseVisualStyleBackColor = false;
            this.btn_generatetable.Click += new System.EventHandler(this.btn_generatetable_Click);
            // 
            // btn_calculate
            // 
            this.btn_calculate.BackColor = System.Drawing.Color.Transparent;
            this.btn_calculate.Font = new System.Drawing.Font("Montserrat", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_calculate.ForeColor = System.Drawing.Color.Black;
            this.btn_calculate.Location = new System.Drawing.Point(35, 98);
            this.btn_calculate.Margin = new System.Windows.Forms.Padding(4);
            this.btn_calculate.Name = "btn_calculate";
            this.btn_calculate.Size = new System.Drawing.Size(211, 53);
            this.btn_calculate.TabIndex = 7;
            this.btn_calculate.Text = "Calculate";
            this.btn_calculate.UseVisualStyleBackColor = false;
            this.btn_calculate.Click += new System.EventHandler(this.btn_calculate_Click);
            // 
            // artanPanel2
            // 
            this.artanPanel2.BackColor = System.Drawing.Color.White;
            this.artanPanel2.BorderRadius = 50;
            this.artanPanel2.Controls.Add(this.label3);
            this.artanPanel2.Controls.Add(this.label2);
            this.artanPanel2.Controls.Add(this.txtbox_jumlahconstraint);
            this.artanPanel2.Controls.Add(this.txtbox_jumlahvariabel);
            this.artanPanel2.ForeColor = System.Drawing.Color.Transparent;
            this.artanPanel2.GradientAngle = 90F;
            this.artanPanel2.GradientBottomColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(61)))), ((int)(((byte)(47)))));
            this.artanPanel2.GradientTopColor = System.Drawing.Color.FromArgb(((int)(((byte)(198)))), ((int)(((byte)(61)))), ((int)(((byte)(47)))));
            this.artanPanel2.Location = new System.Drawing.Point(55, 111);
            this.artanPanel2.Name = "artanPanel2";
            this.artanPanel2.Size = new System.Drawing.Size(276, 167);
            this.artanPanel2.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Montserrat", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(31, 18);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(136, 24);
            this.label3.TabIndex = 6;
            this.label3.Text = "Input Variabel";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Montserrat", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(31, 94);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(156, 24);
            this.label2.TabIndex = 5;
            this.label2.Text = "Input Constraint";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // txtbox_jumlahconstraint
            // 
            this.txtbox_jumlahconstraint.Location = new System.Drawing.Point(35, 122);
            this.txtbox_jumlahconstraint.Margin = new System.Windows.Forms.Padding(4);
            this.txtbox_jumlahconstraint.Name = "txtbox_jumlahconstraint";
            this.txtbox_jumlahconstraint.Size = new System.Drawing.Size(208, 22);
            this.txtbox_jumlahconstraint.TabIndex = 1;
            // 
            // txtbox_jumlahvariabel
            // 
            this.txtbox_jumlahvariabel.Location = new System.Drawing.Point(35, 46);
            this.txtbox_jumlahvariabel.Margin = new System.Windows.Forms.Padding(4);
            this.txtbox_jumlahvariabel.Name = "txtbox_jumlahvariabel";
            this.txtbox_jumlahvariabel.Size = new System.Drawing.Size(208, 22);
            this.txtbox_jumlahvariabel.TabIndex = 0;
            // 
            // form_main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1509, 759);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.artanPanel1);
            this.Controls.Add(this.datagrid_useroutput);
            this.Controls.Add(this.datagrid_userinput);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "form_main";
            this.Text = "Kelompok 1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)(this.datagrid_userinput)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid_useroutput)).EndInit();
            this.artanPanel1.ResumeLayout(false);
            this.artanPanel1.PerformLayout();
            this.artanPanel4.ResumeLayout(false);
            this.artanPanel4.PerformLayout();
            this.artanPanel3.ResumeLayout(false);
            this.artanPanel2.ResumeLayout(false);
            this.artanPanel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtbox_jumlahvariabel;
        private System.Windows.Forms.TextBox txtbox_jumlahconstraint;
        private System.Windows.Forms.Button btn_generatetable;
        private System.Windows.Forms.DataGridView datagrid_userinput;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_calculate;
        private System.Windows.Forms.DataGridView datagrid_useroutput;
        private System.Windows.Forms.ComboBox combobox_tabeliterasi;
        private System.Windows.Forms.Button btn_tampilkantabel;
        private ArtanPanel artanPanel1;
        private ArtanPanel artanPanel4;
        private ArtanPanel artanPanel3;
        private ArtanPanel artanPanel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}

